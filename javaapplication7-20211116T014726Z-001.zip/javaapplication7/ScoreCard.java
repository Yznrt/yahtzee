/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication7;

/**
 *
 * @author Home
 */

public class ScoreCard
{
//Add member variables
private UpperSection upper;
private LowerSection lower;
private int grandTotal;
//Create getter/setter for member variables
public UpperSection getUpper()
{
return upper;
}
public void setUpper(UpperSection upper)
{
this.upper = upper;
}
public LowerSection getLower()
{
return lower;
}
public void setLower(LowerSection lower)
{
this.lower = lower;
}
public int getGrandTotal()
{
return grandTotal;
}
public void setGrandTotal(int grandTotal)
{
this.grandTotal = grandTotal;
}
}

