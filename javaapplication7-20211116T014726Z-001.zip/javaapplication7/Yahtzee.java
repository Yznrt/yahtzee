/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication7;

/**
 *
 * @author Home
 */

public class Yahtzee
{
 	public static void main(String args[])
 	{
      	//Instantiate an instance of class Game
      	Game game = new Game();
      	//Call method displayPlayers() in class Game
      	game.displayPlayers();
      	//Call method playGame() in class Game
      	game.playGame();
 	}
}
