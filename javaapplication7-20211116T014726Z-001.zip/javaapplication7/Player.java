/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication7;

/**
 *
 * @author Home
 */

public class Player
{
 	//Add member variables
 	private String name;
 	private ScoreCard score;
 	private Roll roll;
 	//Create getter/setter for member variables
 	public String getName()
 	{
      	return name;
 	}
 	public void setName(String name)
 	{
      	this.name = name;
 	}
 	public ScoreCard getScore()
 	{
      	return score;
 	}
 	public void setScore(ScoreCard score)
 	{
      	this.score = score;
 	}
 	public Roll getRoll()
 	{
      	return roll;
 	}
 	public void setRoll(Roll roll)
 	{
      	this.roll = roll;
 	}
 	//no-argument constructor
 	public Player()
 	{
      	//Instantiate an instance of the declared member variable roll
      	roll = new Roll();
 	}
 	public void rollDice()
 	{
      	//call method rollDice() of member variable roll
      	roll.rollDice();
 	}
}
