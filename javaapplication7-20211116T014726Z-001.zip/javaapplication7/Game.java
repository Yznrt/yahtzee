/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication7;

/**
 *
 * @author Home
 */

import java.util.ArrayList;
import java.util.Scanner;
public class Game
{
 	//Add member variables:
 	private int gameTurn;
 	private ArrayList<Player> playersplay;
 	Scanner input = new Scanner(System.in);
 	//Create getter/setter for member variables
 	public int getGameTurn()
 	{
      	return gameTurn;
 	}
 	public void setGameTurn(int gameTurn)
 	{
      	//this.gameMove = gameMove;
 	}
 	public ArrayList<Player> getPlayer()
 	{
      	return playersplay;
 	}
 	public void setPlayer(ArrayList<Player> player)
 	{
      	this.playersplay = player;
 	}
 	public Scanner getInput()
 	{
      	return input;
 	}
 	public void setInput(Scanner input)
 	{
      	this.input = input;
 	}
    
 	//the no-argument constructor Game
 	public Game()
 	{
      	playersplay= new ArrayList<Player>();
         
      	//Prompt the user for number of playersplay
      	System.out.print("Enter number of playersplay: ");
      	//Read in data entered by user
      	int n = input.nextInt();
      	//Loop through number of playersplay and call method newPlayer()
      	for(int i=0;i<n;i++)
      	{
          	newPlayer();
      	}
 	}
 	public void newPlayer()
 	{
      	//prompt the user for the player’s name
      	System.out.print("Enter the name of the player: ");
      	//read in the data entered by the user
      	String name = input.next();
         
      	//instantiate and instance of class Player
      	Player p = new Player();
      	//call the setter method for member variable name
      	//passing the user’s input as an argument
      	p.setName(name);
      	//add the instance of Player to the playersplay member variable
      	playersplay.add(p);
 	}
 	public void displayPlayers()
 	{
      	System.out.println(" The playersplay are:");
      	//loop through the member variable playersplay and
      	//display to the console the result of calling method getName()
      	for (Player p : playersplay)
      	{
          	System.out.println(p.getName());
      	}
 	}    
 	public void playGame()
 	{
      	//loop through the member variable playersplay and call method rollDice()
      	for (Player p : playersplay)
      	{
          	p.rollDice();
      	}
 	}
}
