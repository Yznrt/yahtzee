/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication7;

/**
 *
 * @author Home
 */

import java.util.Random;
public class Die
{
 	//Add member variables
 	//faceValue, data type int
 	private int faceValue;
 	//Create getter/setter for member variable
 	public int getFaceValue()
 	{
      	return faceValue;
 	}
 	public void setFaceValue(int faceValue)
 	{
      	this.faceValue = faceValue;
 	}
 	public void rollDie()
 	{
      	Random random = new Random();
      	//Set the value of member variable
      	//faceValue to a random number between 1 and 6
      	faceValue = random.nextInt(6)+1;
 	}
 	//Override class Object’s method toString()
 	//that returns a String value of member variable faceValue
 	@Override
 	public String toString()
 	{
      	return "Die [faceValue=" + faceValue + "]";
 	}   
}

